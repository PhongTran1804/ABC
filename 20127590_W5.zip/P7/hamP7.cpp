#include "P7.h"
void phepchia(int a, int d)
{
	int q, r;
	for (int q = 1; q <= a; q++)
	{
		for (int r = 0; r < d; r++)
		{
			if ((q * d + r) == a)
			{
				cout <<a<<" chia "<<d<<" = "<< q << " du " << r;
			}
		}
	}

}