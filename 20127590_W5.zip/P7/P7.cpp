#include "P7.h"
int main()
{
	int a, d;
	cout << "Nhap 2 so nguyen duong a>=0 va d>0: ";
	cin >> a >> d;
	if(a<0||d==0)
		do
		{
			cout << "Vui long nhap lai 2 so nguyen duong a>=0 va d>0: ";
			cin >> a >> d;
		} while (a < 0 && d == 0);
		phepchia(a, d); cout << endl;
		return 0;
}