#include <iostream>
using namespace std;
void phepchia(int a, int d);//ham tinh a chia d 
