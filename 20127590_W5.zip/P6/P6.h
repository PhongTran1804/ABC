#include <iostream>
using namespace std;
void inbinhphuongN(int n);
void inbinhphuongNsonguyenduongdautien(int n);