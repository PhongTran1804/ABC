#include"P6.h"
int main()
{
	int n;
	cout << "Nhap so nguyen duong n: "; cin >> n;
	cout << "Binh phuong cua " << n << " so dau tien la: "<<endl;
	inbinhphuongNsonguyenduongdautien(n);
}