#include"P6.h"
void inbinhphuongN(int n)
{
	for (int i = 1; i <= n; i++)
		cout << n << "+";
}
void inbinhphuongNsonguyenduongdautien(int n)
{
	for (int i = 1; i <= n; i++)
	{
		inbinhphuongN(i);
		cout <<0<< endl;
	}
}