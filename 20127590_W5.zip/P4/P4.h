#include<iostream>
#include<cmath>
using namespace std;
bool KiemTraSoDoiXung(int n);
bool KiemTraSoGanDoiXung(int n);
int KiemTraSoTangDanHoacGiamDan(int n);
void ChuSoLonNhatVaNhonhat(int n);
int SoDaoNguoc(int n);
int DemSoChuSo(int n);
