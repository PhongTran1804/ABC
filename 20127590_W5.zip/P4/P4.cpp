#include"P4.h"
int main()
{
	int n;
	cout << "Nhap so nguyen duong n: "; cin >> n;
	if (KiemTraSoDoiXung(n) == true) cout << n << " la so doi xung" << endl;
	else cout << n << " khong la so doi xung" << endl;
	if (KiemTraSoGanDoiXung(n) == true) cout << n << " la so gan doi xung" << endl;
	else cout << n << " khong la so gan doi xung" << endl;
	if (KiemTraSoTangDanHoacGiamDan(n) == 1) cout << n << " la so tang dan" << endl;
	if (KiemTraSoTangDanHoacGiamDan(n) == 2) cout << n << " la so giam dan" << endl;
	if (KiemTraSoTangDanHoacGiamDan(n) == 0) cout << n << " khong la so tang/giam dan" << endl;
	ChuSoLonNhatVaNhonhat(n);
}

