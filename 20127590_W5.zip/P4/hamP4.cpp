#include"P4.h"
bool KiemTraSoDoiXung(int n)
{
	int a, sodaonguoc=0, tmp=n;
	while (tmp != 0)
	{
		a = tmp % 10;
		sodaonguoc = sodaonguoc * 10 + a;
		tmp /= 10;
	}
	if (sodaonguoc == n) return true;
	return false;
}

int KiemTraSoTangDanHoacGiamDan(int n)
{
	int a, b, kt1 = 0, kt2 = 0;
	a = n % 10;
	n /= 10;
	while (n != 0)
	{
		b = n % 10;
		if (a < b) kt1 = 1;
		if (a > b) kt2 = 1;
		a = b;
		n /= 10;
	}
	if (kt1 == 0 && kt2 == 1) return 1;
	if (kt1 == 1 && kt2 == 0) return 2;
	if ((kt1 == 1 && kt2 == 1) || (kt1 == 0 && kt2 == 0)) return 0;

}
void ChuSoLonNhatVaNhonhat(int n)
{
	int a, max = 0, min = 9, n1;
	n1 = n;
	while (n != 0)
	{
		a = n % 10;
		if (a > max) max = a;
		if (a < min) min = a;
		n /= 10;
	}
	cout << "Chu So Lon Nhat trong " << n1 << " la: " << max << endl;
	cout << "Chu So Nho Nhat trong " << n1 << " la: " << min << endl;

}

bool KiemTraSoGanDoiXung(int n)
{
	int a,b,cacchusodau, cacchusosau, kiemtra=0, k= pow(10, DemSoChuSo(n) / 2);//k la 10 mu so chu so chia 2
	cacchusodau = n / k; 
	cacchusosau = SoDaoNguoc(n) / k; 
		while (cacchusodau != 0 && cacchusosau!=0)
		{
			a = cacchusodau % 10;
			b = cacchusosau % 10;
			if (a != b)
			{
				kiemtra++;
			}
			cacchusodau /= 10;
			cacchusosau /= 10;
		}
		if (kiemtra == 1) return true;
		return false;
}

int SoDaoNguoc(int n)
{
	int a, sodaonguoc = 0;
	while (n != 0)
	{
		a = n % 10;
		sodaonguoc = sodaonguoc * 10 + a;
		n /= 10;
	}
	return sodaonguoc;
}
int DemSoChuSo(int n)
{
	int a, sochuso = 0;
	while (n != 0)
	{
		a = n % 10;
		sochuso++;
		n /= 10;
	}
	return sochuso;
}