#include<iostream>
using namespace std;
bool KiemTraSoNguyenTo(int n);
void InSoNguyenTo(int n);
void InThuaSoNguyenTo(int n);
void InCacChuSoTuPhaiQuaTrai(int n);
int SoDaoNguoc(int n);
void TongCacChuSoNhoHon10(int n);

