#include "P1.h"
int main()
{
	int n;
	cout << "Nhap so nguyen duong n: "; cin >> n;
	if (KiemTraSoNguyenTo(n) == true) cout << n << " la so nguyen to"<<endl;
	else cout << n << " khong la so nguyen to"<<endl;
	cout << "Cac so nguyen to nho hon " << n << " la: ";
	InSoNguyenTo(n);
	cout << endl;
	cout << "Thua so nguyen to la: ";
	InThuaSoNguyenTo(n); cout << 1<<endl;
	cout << n << " in tu trai sang phai la: "; InCacChuSoTuPhaiQuaTrai(n); cout << endl;
	cout << n << " in tu phai sang trai la: "; 
	InCacChuSoTuPhaiQuaTrai(SoDaoNguoc(n)); cout << endl;
	TongCacChuSoNhoHon10(n);
}