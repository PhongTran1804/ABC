#include "P1.h"
bool KiemTraSoNguyenTo(int n)
{
	int dem = 0;
	for (int i = 1; i <= n; i++)
		if (n % i == 0) dem++;
	if (dem == 2)
		return true; 
		return false;
}

void InSoNguyenTo(int n)
{
	for (int i = 1; i <= n; i++)
		if (KiemTraSoNguyenTo(i) == true) 
			cout << i << " ";
}

void InThuaSoNguyenTo(int n)
{
	for (int i = 2; i <= n; i++)
	{
		while (n % i == 0)
		{
			cout << i << "x";
			n /= i;
		}
	}
}
/// <summary>
/// ////////////////////////////////////////
/// </summary>
/// <param name="n"></param>
void InCacChuSoTuPhaiQuaTrai(int n)
{
	int a;
	while (n !=0 )
	{
		a = n % 10;
		cout << a << " ";
		n /= 10;
	}
}
/// <summary>
/// ///////////////////////////////////////////////
/// </summary>
/// <param name="n"></param>
/// <returns></returns>
int SoDaoNguoc(int n)
{
	int sodaonguoc = 0;
	int a;
	while (n != 0)
	{
		a = n % 10;
		sodaonguoc = sodaonguoc * 10 + a;
		n /= 10;
	}
	return sodaonguoc;
}
//////////////////////////////////////////////////////
void TongCacChuSoNhoHon10(int n)
{
	int tong = 0,tongmoi=0, a;
	while (n != 0)
	{
		a = n % 10;
		tong += a;
		n /= 10;
	}
	while (tong > 10)
	{
		a = tong % 10;
		tongmoi += a;
		tong /= 10;
	}
	cout << "Tong la: " << tongmoi;
}