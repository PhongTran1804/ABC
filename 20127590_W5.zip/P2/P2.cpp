#include "P2.h"
int main()
{
	int a,b;
	cout << "Nhap so nguyen duong a va b: "; cin >> a>>b;
	cout << "Uoc chung lon nhat cua " << a << " va " << b << " la: " << ucln(a, b)<<endl;
	cout << "Boi chung nho nhat cua " << a << " va " << b << " la: " << bcnn(a, b)<<endl;
}