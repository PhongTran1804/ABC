#include<iostream>
using namespace std;
int ucln(int a, int b);
int bcnn(int a, int b);
