#include"P2.h"
int max(int a, int b)
{
	if (a > b)
		return a;
	return b;
}
int min(int a, int b)
{
	if (a > b)
		return b;
	return a;
}

int ucln(int a, int b)
{
	for (int i = min(a, b); i > 1; i--)
	{
		if (a % i == 0 && b % i == 0) 
			return i;
	}
}

int bcnn(int a, int b)
{
	for (int i = max(a, b); i>0; i++)
	if (i % a == 0 && i % b == 0) return i;
}