#include"P5.h"
int Fibonacci(int n)
{
	if (n == 1 || n == 0)
		return 1;
	return Fibonacci(n - 1) + Fibonacci(n - 2);
}