#include"P5.h"
int main()
{
	int k;
	cout << "Nhap phan tu thu k trong day Fibonacci: ";
	cin >> k;
	cout << "Phan tu thu " << k << " trong day Fibonacci la: " << Fibonacci(k);
	return 0;
}