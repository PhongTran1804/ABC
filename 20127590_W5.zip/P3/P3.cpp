#include "P3.h"
int main()
{
	int a, b, c;
	cout << "Nhap so nguyen duong a va b va c: ";
	cin >> a >> b >> c;
	cout << "Uoc chung lon nhat cua " << a<<" " << b << " " << c<<" la: " << ucln(a, b, c) << endl;
	return 0;
}