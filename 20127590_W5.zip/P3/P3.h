#include<iostream>
using namespace std;
int ucln(int a, int b, int c);
