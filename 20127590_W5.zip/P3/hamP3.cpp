#include "P3.h"
int min(int a, int b, int c)
{
	if (a < b && a < c)
		return a;
	if (b < a && b < c)
		return b;
	if (c < a && c < b)
		return c;
}
int ucln(int a, int b, int c)
{
	for (int i = min(a, b, c); i > 0; i--)
		if (a % i == 0 && b% i == 0 && c % i == 0) return i;
}